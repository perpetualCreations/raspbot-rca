#!/bin/sh
sudo raspbotrca-host-manualstart
