#!/usr/bin/env bash
raspbotrca-host-manualstart
